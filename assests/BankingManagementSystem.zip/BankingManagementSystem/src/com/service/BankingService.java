package com.service;

import java.util.Collection;
import java.util.LinkedHashMap;

import com.model.Account;
import com.model.CurrentAccount;
import com.model.Customer;
import com.model.SavingsAccount;

public class BankingService {
	LinkedHashMap<String, Customer> customers = new LinkedHashMap<String, Customer>();
	LinkedHashMap<String, Account> accounts = new LinkedHashMap<String, Account>();

	public void createcustomer(String id, String name) {
		if (customers.containsKey(id)) {
			System.out.println("Customer id already exist.....");
		} else {
			Customer customer = new Customer(id, name);
			customers.put(id, customer);
			System.out.println("Customer created successfully " + customer);
		}
	}

	public void createcustomer(String cus_id, String acc_type, String acc_number, double balance) {
		if (customers.containsKey(cus_id)) {
			if (accounts.containsKey(acc_number)) {
				System.out.println("Account number already exist");
			} else {
				Customer customer = customers.get(cus_id);
				if (acc_type.equalsIgnoreCase("Savings")) {
					Account account = new SavingsAccount(acc_number, customer, balance);
					accounts.put(acc_number, account);
					System.out.println("Savings account created Successfully" + account);
				} else if (acc_type.equalsIgnoreCase("Current")) {
					Account account = new CurrentAccount(acc_number, customer, balance);
					accounts.put(acc_number, account);
					System.out.println("Current account created Successfully" + account);

				} else {
					System.out.println("Invalid account type");
				}
			}

		} else {
			System.out.println("Customer not Exist");
		}
	}

	public void deposit(String dep_acc_number, double dep_amount) {
		if (accounts.containsKey(dep_acc_number)) {
			Account account = accounts.get(dep_acc_number);
			account.deposit(dep_amount);
		} else {
			System.out.println("Invalid Account Number");
		}

	}

	public void withdraw(String wd_acc_number, double wd_amount) {

		if (accounts.containsKey(wd_acc_number)) {
			Account account = accounts.get(wd_acc_number);
			account.withdraw(wd_amount);
		} else {
			System.out.println("Invalid Account Number");
		}
	}

	public void viewBalance(String chk_acc_number) {

		if (accounts.containsKey(chk_acc_number)) {
			Account account = accounts.get(chk_acc_number);
			System.out.println("Available balnce is " + account.getBalance());
		} else {
			System.out.println("Invalid Account Number");
		}
	}

	public void viewAccounts() {
		Collection<Account> view = accounts.values();
		for (Account obj : view) {
			System.out.println(obj);
		}

	}
}