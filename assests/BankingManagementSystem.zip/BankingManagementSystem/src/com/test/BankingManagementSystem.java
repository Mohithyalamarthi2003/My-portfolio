package com.test;

import java.util.Scanner;

import com.service.BankingService;

public class BankingManagementSystem {

	public static void main(String[] args) {
		BankingService service = new BankingService();
		Scanner scanner = new Scanner(System.in);
		while (true) {
			System.out.println("*********************************************************");
			System.out.println("*********************************************************");
			System.out.println("******************    Welcome To      *******************");
			System.out.println("**********   Banking Managrment System  *****************");
			System.out.println("*********************************************************");
			System.out.println("***************** 1. Create Customer  *******************");
			System.out.println("***************** 2. Create Account   *******************");
			System.out.println("***************** 3. Deposit Amount    ******************");
			System.out.println("***************** 4. Withdraw Amount   ******************");
			System.out.println("***************** 5. Check Balance    *******************");
			System.out.println("***************** 6. View Accounts     ******************");
			System.out.println("***************** 7. Exit              ******************");
			System.out.println("*********************************************************");
			System.out.println("*********************************************************");
			System.out.println("Enter your choice : ");
			int choice = scanner.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Enter customer id :");
				String id = scanner.next();
				System.out.println("Enter customer name:");
				String name = scanner.next();
				service.createcustomer(id, name);
				break;

			case 2:
				System.out.println("Enter customer id :");
				String cus_id = scanner.next();
				System.out.println("Enter type of account : Saving / Current");
				String acc_type = scanner.next();
				System.out.println("Enter account number :");
				String acc_number = scanner.next();
				System.out.println("Enter initial balance :");
				double balance = scanner.nextDouble();
				service.createcustomer(cus_id, acc_type, acc_number, balance);
				break;

			case 3:
				System.out.println("Enter Account Number");
				String dep_acc_number = scanner.next();
				System.out.println("Enter Amount");
				double dep_amount = scanner.nextDouble();
				service.deposit(dep_acc_number, dep_amount);
				break;
			case 4:
				System.out.println("Enter Account Number");
				String wd_acc_number = scanner.next();
				System.out.println("Enter Amount");
				double wd_amount = scanner.nextDouble();
				service.withdraw(wd_acc_number, wd_amount);
				break;
			case 5:
				System.out.println("Enter Account Number");
				String chk_acc_number = scanner.next();
				service.viewBalance(chk_acc_number);
				break;
			case 6:
				service.viewAccounts();
				break;
			case 7:
				System.exit(0);
				break;
			default:
				System.out.println("Please Enter Valid Choice");
				break;
			}
		}

	}

}